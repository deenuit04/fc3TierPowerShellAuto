$ErrorActionPreference = "Stop"

try
{
   write-host "Creating App Tier NSG" -ForegroundColor Yellow

   $appAsg = New-AzApplicationSecurityGroup `
  -ResourceGroupName "fc3TierVnetResourceGroup" `
  -Name "fc3TierASGAppServers" `
  -Location "CentralIndia"

   $mgmtAsg = New-AzApplicationSecurityGroup `
  -ResourceGroupName "fc3TierVnetResourceGroup" `
  -Name "fc3TierASGMgmtAppServers" `
  -Location "CentralIndia"

   $appRule = New-AzNetworkSecurityRuleConfig `
  -Name "Allow-App-All" `
  -Access Allow `
  -Protocol Tcp `
  -Direction Inbound `
  -Priority 100 `
  -SourceAddressPrefix Internet `
  -SourcePortRange * `
  -DestinationApplicationSecurityGroupId $appAsg.id `
  -DestinationPortRange 80,443

  
   $mgmtRule = New-AzNetworkSecurityRuleConfig `
  -Name "Allow-RDPApp-All" `
  -Access Allow `
  -Protocol Tcp `
  -Direction Inbound `
  -Priority 110 `
  -SourceAddressPrefix Internet `
  -SourcePortRange * `
  -DestinationApplicationSecurityGroupId $mgmtAsg.id `
  -DestinationPortRange 3389

  $nsg = New-AzNetworkSecurityGroup `
  -ResourceGroupName "fc3TierVnetResourceGroup" `
  -Location "CentralIndia" `
  -Name "fcAppTierNsg" `
  -SecurityRules $appRule,$mgmtRule

   write-host "App Tier NSG creation completed" -ForegroundColor Green
}
catch
{
   write-host "An exception occured:" -ForegroundColor Red
   write-host "Exception Type: $($_.Exception.GetType().FullName)" -ForegroundColor Red
   write-host "Exception Message: $($_.Exception.Message)" -ForegroundColor Red
}
finally
{

}

