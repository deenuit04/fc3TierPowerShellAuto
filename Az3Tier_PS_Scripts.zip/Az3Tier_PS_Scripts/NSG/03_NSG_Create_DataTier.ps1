$ErrorActionPreference = "Stop"

try
{
   write-host "Creating Data Tier NSG" -ForegroundColor Yellow

   $appAsg = New-AzApplicationSecurityGroup `
  -ResourceGroupName "fc3TierVnetResourceGroup" `
  -Name "fc3TierASGDataServers" `
  -Location "CentralIndia"

   $mgmtAsg = New-AzApplicationSecurityGroup `
  -ResourceGroupName "fc3TierVnetResourceGroup" `
  -Name "fc3TierASGMgmtDataServers" `
  -Location "CentralIndia"

   $dataRule = New-AzNetworkSecurityRuleConfig `
  -Name "Allow-Data-All" `
  -Access Allow `
  -Protocol Tcp `
  -Direction Inbound `
  -Priority 100 `
  -SourceAddressPrefix Internet `
  -SourcePortRange * `
  -DestinationApplicationSecurityGroupId $appAsg.id `
  -DestinationPortRange 1433,1434,80,443

  
   $mgmtRule = New-AzNetworkSecurityRuleConfig `
  -Name "Allow-RDPData-All" `
  -Access Allow `
  -Protocol Tcp `
  -Direction Inbound `
  -Priority 110 `
  -SourceAddressPrefix Internet `
  -SourcePortRange * `
  -DestinationApplicationSecurityGroupId $mgmtAsg.id `
  -DestinationPortRange 3389

  $nsg = New-AzNetworkSecurityGroup `
  -ResourceGroupName "fc3TierVnetResourceGroup" `
  -Location "CentralIndia" `
  -Name "fcDataTierNsg" `
  -SecurityRules $dataRule,$mgmtRule

   write-host "Data Tier NSG creation completed" -ForegroundColor Green
}
catch
{
   write-host "An exception occured:" -ForegroundColor Red
   write-host "Exception Type: $($_.Exception.GetType().FullName)" -ForegroundColor Red
   write-host "Exception Message: $($_.Exception.Message)" -ForegroundColor Red
}
finally
{

}

