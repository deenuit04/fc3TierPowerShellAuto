$ErrorActionPreference = "Stop"

try
{
   write-host "Create the frontend IP pool" -ForegroundColor Yellow

  $vnet = Get-AzVirtualNetwork -Name fc3TierVnet -ResourceGroupName fc3TierVnetResourceGroup

  $backendSubnet = Get-AzVirtualNetworkSubnetConfig `
  -Name DataTier `
  -VirtualNetwork $vnet        

  $frontendIP = New-AzLoadBalancerFrontendIpConfig `
  -Name DataTierFrontEnd `
  -PrivateIpAddress 192.168.3.5 -SubnetId $backendSubnet.Id

  write-host "Create the backend address pool" -ForegroundColor Yellow

  $backendPool = New-AzLoadBalancerBackendAddressPoolConfig `
  -Name DataTierBackEndPool

  write-host "Create inbound NAT rules" -ForegroundColor Yellow

  $inboundNATRule1 = New-AzLoadBalancerInboundNatRuleConfig -Name "DataTierRDP1" -FrontendIpConfiguration $frontendIP -Protocol TCP -FrontendPort 3441 -BackendPort 3389

  $inboundNATRule2 = New-AzLoadBalancerInboundNatRuleConfig -Name "DataTierRDP2" -FrontendIpConfiguration $frontendIP -Protocol TCP -FrontendPort 3442 -BackendPort 3389

  write-host "Create Load Balancer rules for traffic on ports 1433, 1434" -ForegroundColor Yellow

  $lbrule1 = New-AzLoadBalancerRuleConfig -Name "DataTierSQL1" -FrontendIpConfiguration $frontendIP -BackendAddressPool $backendPool -Protocol Tcp -FrontendPort 1433 -BackendPort 1433

  $lbrule2 = New-AzLoadBalancerRuleConfig -Name "DataTierSQL2" -FrontendIpConfiguration $frontendIP -BackendAddressPool $backendPool -Protocol Tcp -FrontendPort 1434 -BackendPort 1434

  write-host "Create the load balancer" -ForegroundColor Yellow

  $lb = New-AzLoadBalancer `
-ResourceGroupName fc3TierVnetResourceGroup `
-Name "fc3TierDataLoadBalancer" `
-Location "SouthIndia" `
-FrontendIpConfiguration $frontendIP `
-InboundNatRule $inboundNATRule1,$inboundNatRule2 `
-LoadBalancingRule $lbrule1,$lbrule2 `
-BackendAddressPool $backendPool

  write-host "Load balancer creation completed" -ForegroundColor Green
}
catch
{
   write-host "An exception occured:" -ForegroundColor Red
   write-host "Exception Type: $($_.Exception.GetType().FullName)" -ForegroundColor Red
   write-host "Exception Message: $($_.Exception.Message)" -ForegroundColor Red
}
finally
{

}

