$ErrorActionPreference = "Stop"

try
{
   write-host "Creating Data Tier NSG" -ForegroundColor Yellow

   $dataAsg = New-AzApplicationSecurityGroup `
  -ResourceGroupName "fc3TierVnetResourceGroup" `
  -Name "fc3TierASGDataServers" `
  -Location "SouthIndia"

   $mgmtAsg = Get-AzApplicationSecurityGroup `
  -ResourceGroupName "fc3TierVnetResourceGroup" `
  -Name "fc3TierASGAppServers" `

   $dataRule = New-AzNetworkSecurityRuleConfig `
  -Name "Allow-Data-All" `
  -Access Allow `
  -Protocol Tcp `
  -Direction Inbound `
  -Priority 100 `
  -SourceApplicationSecurityGroup $mgmtAsg `
  -SourcePortRange * `
  -DestinationApplicationSecurityGroup $dataAsg `
  -DestinationPortRange 1433,1434,80,443,3389
   

  $nsg = New-AzNetworkSecurityGroup `
  -ResourceGroupName "fc3TierVnetResourceGroup" `
  -Location "SouthIndia" `
  -Name "fcDataTierNsg" `
  -SecurityRules $dataRule

   write-host "Data Tier NSG creation completed" -ForegroundColor Green
}
catch
{
   write-host "An exception occured:" -ForegroundColor Red
   write-host "Exception Type: $($_.Exception.GetType().FullName)" -ForegroundColor Red
   write-host "Exception Message: $($_.Exception.Message)" -ForegroundColor Red
}
finally
{

}

