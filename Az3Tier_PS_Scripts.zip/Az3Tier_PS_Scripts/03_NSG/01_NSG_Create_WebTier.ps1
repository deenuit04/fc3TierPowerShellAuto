$ErrorActionPreference = "Stop"

try
{
   write-host "Creating Web Tier NSG" -ForegroundColor Yellow

   $webAsg = New-AzApplicationSecurityGroup `
  -ResourceGroupName "fc3TierVnetResourceGroup" `
  -Name "fc3TierASGWebServers" `
  -Location "SouthIndia"

   $webRule = New-AzNetworkSecurityRuleConfig `
  -Name "Allow-Web-All" `
  -Access Allow `
  -Protocol Tcp `
  -Direction Inbound `
  -Priority 100 `
  -SourceAddressPrefix Internet `
  -SourcePortRange * `
  -DestinationApplicationSecurityGroup $webAsg `
  -DestinationPortRange 80,443,3389

  $nsg = New-AzNetworkSecurityGroup `
  -ResourceGroupName "fc3TierVnetResourceGroup" `
  -Location "SouthIndia" `
  -Name "fcWebTierNsg" `
  -SecurityRules $webRule

   write-host "Web Tier NSG creation completed" -ForegroundColor Green
}
catch
{
   write-host "An exception occured:" -ForegroundColor Red
   write-host "Exception Type: $($_.Exception.GetType().FullName)" -ForegroundColor Red
   write-host "Exception Message: $($_.Exception.Message)" -ForegroundColor Red
}
finally
{

}

