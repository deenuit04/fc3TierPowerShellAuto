$ErrorActionPreference = "Stop"

try
{
   write-host "Creating App Tier NSG" -ForegroundColor Yellow

   $appAsg = New-AzApplicationSecurityGroup `
  -ResourceGroupName "fc3TierVnetResourceGroup" `
  -Name "fc3TierASGAppServers" `
  -Location "CentralIndia"

   $mgmtAsg = Get-AzApplicationSecurityGroup `
  -ResourceGroupName "fc3TierVnetResourceGroup" `
  -Name "fc3TierASGWebServers" `  

   $appRule = New-AzNetworkSecurityRuleConfig `
  -Name "Allow-App-All" `
  -Access Allow `
  -Protocol Tcp `
  -Direction Inbound `
  -Priority 100 `
  -SourceApplicationSecurityGroup $mgmtAsg `
  -SourcePortRange * `
  -DestinationApplicationSecurityGroup $appAsg `
  -DestinationPortRange 80,443,3389

  $nsg = New-AzNetworkSecurityGroup `
  -ResourceGroupName "fc3TierVnetResourceGroup" `
  -Location "CentralIndia" `
  -Name "fcAppTierNsg" `
  -SecurityRules $appRule

   write-host "App Tier NSG creation completed" -ForegroundColor Green
}
catch
{
   write-host "An exception occured:" -ForegroundColor Red
   write-host "Exception Type: $($_.Exception.GetType().FullName)" -ForegroundColor Red
   write-host "Exception Message: $($_.Exception.Message)" -ForegroundColor Red
}
finally
{

}

