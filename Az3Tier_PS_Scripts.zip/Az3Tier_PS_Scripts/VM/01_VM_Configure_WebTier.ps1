$ErrorActionPreference = "Stop"

try
{
   write-host "Configure Web Tier VM Availability Set" -ForegroundColor Yellow
   
   New-AzAvailabilitySet `
   -Location "CentralIndia" `
   -Name "fcWebTierAvailabilitySet" `
   -ResourceGroupName "fc3TierVnetResourceGroup" `
   -Sku aligned `
   -PlatformFaultDomainCount 2 `
   -PlatformUpdateDomainCount 2

   write-host "Configure Web Tier VM Availability Set completed" -ForegroundColor Green
   
   write-host "Configure Web Tier VMs" -ForegroundColor Yellow

   $cred = Get-Credential
   for ($i=1; $i -le 2; $i++)
   {
    New-AzVm `
        -ResourceGroupName "fc3TierVnetResourceGroup" `
        -Name "fcWebTierVM$i" `
        -Location "CentralIndia" `
        -VirtualNetworkName "fc3TierVnet" `
        -SubnetName "WebTier" `
        -SecurityGroupName "fc3TierASGWebServers" `
        -PublicIpAddressName "fcWebTierVMPublicIpAddress$i" `
        -AvailabilitySetName "fcWebTierAvailabilitySet" `
        -Credential $cred
   }

   write-host "Web Tier VM configuration completed" -ForegroundColor Green
}
catch
{
   write-host "An exception occured:" -ForegroundColor Red
   write-host "Exception Type: $($_.Exception.GetType().FullName)" -ForegroundColor Red
   write-host "Exception Message: $($_.Exception.Message)" -ForegroundColor Red
}
finally
{

}

