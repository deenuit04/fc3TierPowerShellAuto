$ErrorActionPreference = "Stop"

try
{
   write-host "Configure App Tier VM Availability Set" -ForegroundColor Yellow
   
   New-AzAvailabilitySet `
   -Location "CentralIndia" `
   -Name "fcAppTierAvailabilitySet" `
   -ResourceGroupName "fc3TierVnetResourceGroup" `
   -Sku aligned `
   -PlatformFaultDomainCount 3 `
   -PlatformUpdateDomainCount 3

   write-host "Configure App Tier VM Availability Set completed" -ForegroundColor Green
   
   write-host "Configure App Tier VMs" -ForegroundColor Yellow

   $cred = Get-Credential
   for ($i=1; $i -le 3; $i++)
   {
    New-AzVm `
        -ResourceGroupName "fc3TierVnetResourceGroup" `
        -Name "fcAppTierVM$i" `
        -Location "CentralIndia" `
        -VirtualNetworkName "fc3TierVnet" `
        -SubnetName "AppTier" `
        -SecurityGroupName "fc3TierASGAppServers" `
        -PublicIpAddressName "fcAppTierVMPublicIpAddress$i" `
        -AvailabilitySetName "fcAppTierAvailabilitySet" `
        -Credential $cred
   }

   write-host "App Tier VM configuration completed" -ForegroundColor Green
}
catch
{
   write-host "An exception occured:" -ForegroundColor Red
   write-host "Exception Type: $($_.Exception.GetType().FullName)" -ForegroundColor Red
   write-host "Exception Message: $($_.Exception.Message)" -ForegroundColor Red
}
finally
{

}

