$ErrorActionPreference = "Stop"

try
{
   write-host "Configure Data Tier VM Availability Set" -ForegroundColor Yellow
   
   New-AzAvailabilitySet `
   -Location "CentralIndia" `
   -Name "fcDataTierAvailabilitySet" `
   -ResourceGroupName "fc3TierVnetResourceGroup" `
   -Sku aligned `
   -PlatformFaultDomainCount 2 `
   -PlatformUpdateDomainCount 2

   write-host "Configure Data Tier VM Availability Set completed" -ForegroundColor Green
   
   write-host "Configure Data Tier VMs" -ForegroundColor Yellow

   $cred = Get-Credential
   for ($i=1; $i -le 2; $i++)
   {
    New-AzVm `
        -ResourceGroupName "fc3TierVnetResourceGroup" `
        -Name "fcDataTierVM$i" `
        -Location "CentralIndia" `
        -VirtualNetworkName "fc3TierVnet" `
        -SubnetName "DataTier" `
        -SecurityGroupName "fc3TierASGDataServers" `
        -PublicIpAddressName "fcDataTierVMPublicIpAddress$i" `
        -AvailabilitySetName "fcDataebTierAvailabilitySet" `
        -Credential $cred
   }

   write-host "Data Tier VM configuration completed" -ForegroundColor Green
}
catch
{
   write-host "An exception occured:" -ForegroundColor Red
   write-host "Exception Type: $($_.Exception.GetType().FullName)" -ForegroundColor Red
   write-host "Exception Message: $($_.Exception.Message)" -ForegroundColor Red
}
finally
{

}

