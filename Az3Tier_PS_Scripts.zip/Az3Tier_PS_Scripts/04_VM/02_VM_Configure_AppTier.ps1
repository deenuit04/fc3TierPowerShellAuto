$ErrorActionPreference = "Stop"

try
{
   $vnet = Get-AzVirtualNetwork -Name fc3TierVnet -ResourceGroupName fc3TierVnetResourceGroup

   $backendSubnet = Get-AzVirtualNetworkSubnetConfig `
  -Name AppTier `
  -VirtualNetwork $vnet

   $appAsg = Get-AzApplicationSecurityGroup `
  -ResourceGroupName "fc3TierVnetResourceGroup" `
  -Name "fc3TierASGAppServers" `

   $nsg = Get-AzNetworkSecurityGroup `
  -ResourceGroupName "fc3TierVnetResourceGroup" `
  -Name "fcAppTierNsg" `

   $lb = Get-AzLoadBalancer `
  -ResourceGroupName fc3TierVnetResourceGroup `
  -Name "fc3TierAppLoadBalancer"

   write-host "Configure App Tier VM Availability Set" -ForegroundColor Yellow
   
   New-AzAvailabilitySet `
   -Location "SouthIndia" `
   -Name "fcAppTierAvailabilitySet" `
   -ResourceGroupName "fc3TierVnetResourceGroup" `
   -Sku aligned `
   -PlatformFaultDomainCount 2 `
   -PlatformUpdateDomainCount 2

   write-host "Configure App Tier VM Availability Set completed" -ForegroundColor Green
   
   write-host "Configure App Tier VMs" -ForegroundColor Yellow

   write-host "Creating NIC1" -ForegroundColor Yellow   
   $nic1 = New-AzNetworkInterface `
-ResourceGroupName "fc3TierVnetResourceGroup" `
-Location "SouthIndia" `
-Subnet $backendSubnet `
-Name "fcAppTierVM1" `
-ApplicationSecurityGroup $appAsg `
-NetworkSecurityGroup $nsg `
-LoadBalancerBackendAddressPool $lb.BackendAddressPools[0] `
-LoadBalancerInboundNatRule $lb.InboundNatRules[0]

   write-host "Creating NIC2" -ForegroundColor Yellow   
   $nic1 = New-AzNetworkInterface `
-ResourceGroupName "fc3TierVnetResourceGroup" `
-Location "SouthIndia" `
-Subnet $backendSubnet `
-Name "fcAppTierVM2" `
-ApplicationSecurityGroup $appAsg `
-NetworkSecurityGroup $nsg `
-LoadBalancerBackendAddressPool $lb.BackendAddressPools[0] `
-LoadBalancerInboundNatRule $lb.InboundNatRules[1]


   write-host "Creating VM1" -ForegroundColor Yellow
New-AzVm `
        -ResourceGroupName "fc3TierVnetResourceGroup" `
        -Name "fcAppTierVM1" `
        -Location "SouthIndia" `
        -VirtualNetworkName "fc3TierVnet" `
        -SubnetName "AppTier" `
        -AvailabilitySetName "fcAppTierAvailabilitySet" `
-AsJob

   write-host "Creating VM2" -ForegroundColor Yellow
New-AzVm `
        -ResourceGroupName "fc3TierVnetResourceGroup" `
        -Name "fcAppTierVM2" `
        -Location "SouthIndia" `
        -VirtualNetworkName "fc3TierVnet" `
        -SubnetName "AppTier" `
        -AvailabilitySetName "fcAppTierAvailabilitySet" `
-AsJob

   write-host "App Tier VM configuration has been scheduled" -ForegroundColor Green
}
catch
{
   write-host "An exception occured:" -ForegroundColor Red
   write-host "Exception Type: $($_.Exception.GetType().FullName)" -ForegroundColor Red
   write-host "Exception Message: $($_.Exception.Message)" -ForegroundColor Red
}
finally
{

}

