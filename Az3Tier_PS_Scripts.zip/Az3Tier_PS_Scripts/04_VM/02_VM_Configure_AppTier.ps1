$ErrorActionPreference = "Stop"

try
{
   $vnet = = Get-AzVirtualNetwork -Name fc3TierVnet -ResourceGroupName fc3TierVnetResourceGroup

   $backendSubnet = Get-AzVirtualNetworkSubnetConfig `
  -Name AppTier `
  -VirtualNetwork $vnet

   $appAsg = Get-AzApplicationSecurityGroup `
  -ResourceGroupName "fc3TierVnetResourceGroup" `
  -Name "fc3TierASGAppServers" `

   $nsg = Get-AzNetworkSecurityGroup `
  -ResourceGroupName "fc3TierVnetResourceGroup" `
  -Name "fcAppTierNsg" `

   $lb = Get-AzLoadBalancer `
  -ResourceGroupName fc3TierVnetResourceGroup `
  -Name "fc3TierAppLoadBalancer"

   write-host "Input Admin user name and password for VMs" -ForegroundColor Yellow
   $cred = Get-Credential

   write-host "Configure App Tier VM Availability Set" -ForegroundColor Yellow
   
   New-AzAvailabilitySet `
   -Location "CentralIndia" `
   -Name "fcAppTierAvailabilitySet" `
   -ResourceGroupName "fc3TierVnetResourceGroup" `
   -Sku aligned `
   -PlatformFaultDomainCount 2 `
   -PlatformUpdateDomainCount 2

   write-host "Configure App Tier VM Availability Set completed" -ForegroundColor Green
   
   write-host "Configure App Tier VMs" -ForegroundColor Yellow
   
   for ($i=1; $i -le 3; $i++)
   {
    New-AzNetworkInterface `
-ResourceGroupName "fc3TierVnetResourceGroup" `
-Location "CentralIndia" `
-Subnet $backendSubnet `
-Name "fcAppTierVM$i" `
-ApplicationSecurityGroup $appAsg `
-NetworkSecurityGroup $nsg `
-LoadBalancerBackendAddressPool $lb.BackendAddressPools[0] `
-LoadBalancerInboundNatRule $lb.InboundNatRules ` 
   
    New-AzVm `
        -ResourceGroupName "fc3TierVnetResourceGroup" `
        -Name "fcAppTierVM$i" `
        -Location "CentralIndia" `
        -VirtualNetworkName "fc3TierVnet" `
        -SubnetName "AppTier" `
        -AvailabilitySetName "fcAppTierAvailabilitySet" `        
        -Credential $cred
        -AsJobs
   }

   write-host "App Tier VM configuration completed" -ForegroundColor Green
}
catch
{
   write-host "An exception occured:" -ForegroundColor Red
   write-host "Exception Type: $($_.Exception.GetType().FullName)" -ForegroundColor Red
   write-host "Exception Message: $($_.Exception.Message)" -ForegroundColor Red
}
finally
{

}

