$ErrorActionPreference = "Stop"

try
{
   $vnet = Get-AzVirtualNetwork -Name fc3TierVnet -ResourceGroupName fc3TierVnetResourceGroup

   $backendSubnet = Get-AzVirtualNetworkSubnetConfig `
  -Name DataTier `
  -VirtualNetwork $vnet

   $dataAsg = Get-AzApplicationSecurityGroup `
  -ResourceGroupName "fc3TierVnetResourceGroup" `
  -Name "fc3TierASGDataServers" `

   $nsg = Get-AzNetworkSecurityGroup `
  -ResourceGroupName "fc3TierVnetResourceGroup" `
  -Name "fcDataTierNsg" `

   $lb = Get-AzLoadBalancer `
  -ResourceGroupName fc3TierVnetResourceGroup `
  -Name "fc3TierDataLoadBalancer"

   write-host "Configure Data Tier VM Availability Set" -ForegroundColor Yellow
   
   New-AzAvailabilitySet `
   -Location "SouthIndia" `
   -Name "fcDataTierAvailabilitySet" `
   -ResourceGroupName "fc3TierVnetResourceGroup" `
   -Sku aligned `
   -PlatformFaultDomainCount 2 `
   -PlatformUpdateDomainCount 2

   write-host "Configure Data Tier VM Availability Set completed" -ForegroundColor Green
   
   write-host "Configure Data Tier VMs" -ForegroundColor Yellow
   
   write-host "Creating NIC1" -ForegroundColor Yellow

$nic1 = New-AzNetworkInterface `
-ResourceGroupName "fc3TierVnetResourceGroup" `
-Location "SouthIndia" `
-Subnet $backendSubnet `
-Name 'fcDataTierVM1' `
-ApplicationSecurityGroup $dataAsg `
-NetworkSecurityGroup $nsg `
-LoadBalancerBackendAddressPool $lb.BackendAddressPools[0] `
-LoadBalancerInboundNatRule $lb.InboundNatRules[0]

   write-host "Creating NIC2" -ForegroundColor Yellow

$nic2 = New-AzNetworkInterface `
-ResourceGroupName "fc3TierVnetResourceGroup" `
-Location "SouthIndia" `
-Subnet $backendSubnet `
-Name 'fcDataTierVM2' `
-ApplicationSecurityGroup $dataAsg `
-NetworkSecurityGroup $nsg `
-LoadBalancerBackendAddressPool $lb.BackendAddressPools[0] `
-LoadBalancerInboundNatRule $lb.InboundNatRules[1]

   write-host "Creating VM1" -ForegroundColor Yellow

New-AzVm `
        -ResourceGroupName "fc3TierVnetResourceGroup" `
        -Name "fcDataTierVM1" `
        -Location "SouthIndia" `
        -VirtualNetworkName "fc3TierVnet" `
        -SubnetName "DataTier" `
        -AvailabilitySetName "fcDataTierAvailabilitySet" `
-AsJob

write-host "Creating VM2" -ForegroundColor Yellow

New-AzVm `
        -ResourceGroupName "fc3TierVnetResourceGroup" `
        -Name "fcDataTierVM2" `
        -Location "SouthIndia" `
        -VirtualNetworkName "fc3TierVnet" `
        -SubnetName "DataTier" `
        -AvailabilitySetName "fcDataTierAvailabilitySet" `
-AsJob

   write-host "Data Tier VM configuration completed" -ForegroundColor Green
}
catch
{
   write-host "An exception occured:" -ForegroundColor Red
   write-host "Exception Type: $($_.Exception.GetType().FullName)" -ForegroundColor Red
   write-host "Exception Message: $($_.Exception.Message)" -ForegroundColor Red
}
finally
{

}

