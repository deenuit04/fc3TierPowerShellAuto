$ErrorActionPreference = "Stop"

try
{
   $vnet = = Get-AzVirtualNetwork -Name fc3TierVnet -ResourceGroupName fc3TierVnetResourceGroup

   $backendSubnet = Get-AzVirtualNetworkSubnetConfig `
  -Name DataTier `
  -VirtualNetwork $vnet

   $dataAsg = Get-AzApplicationSecurityGroup `
  -ResourceGroupName "fc3TierVnetResourceGroup" `
  -Name "fc3TierASGDataServers" `

   $nsg = Get-AzNetworkSecurityGroup `
  -ResourceGroupName "fc3TierVnetResourceGroup" `
  -Name "fcDataTierNsg" `

   $lb = Get-AzLoadBalancer `
  -ResourceGroupName fc3TierVnetResourceGroup `
  -Name "fc3TierDataLoadBalancer"

   write-host "Input Admin user name and password for VMs" -ForegroundColor Yellow
   $cred = Get-Credential

   write-host "Configure Data Tier VM Availability Set" -ForegroundColor Yellow
   
   New-AzAvailabilitySet `
   -Location "CentralIndia" `
   -Name "fcDataTierAvailabilitySet" `
   -ResourceGroupName "fc3TierVnetResourceGroup" `
   -Sku aligned `
   -PlatformFaultDomainCount 2 `
   -PlatformUpdateDomainCount 2

   write-host "Configure Data Tier VM Availability Set completed" -ForegroundColor Green
   
   write-host "Configure Data Tier VMs" -ForegroundColor Yellow
   
   for ($i=1; $i -le 2; $i++)
   {
    New-AzNetworkInterface `
-ResourceGroupName "fc3TierVnetResourceGroup" `
-Location "CentralIndia" `
-Subnet $backendSubnet `
-Name 'fcDataTierVM$i' `
-ApplicationSecurityGroup $dataAsg `
-NetworkSecurityGroup $nsg `
-LoadBalancerBackendAddressPool $lb.BackendAddressPools[0] `
-LoadBalancerInboundNatRule $lb.InboundNatRules ` 
   
    New-AzVm `
        -ResourceGroupName "fc3TierVnetResourceGroup" `
        -Name "fcDataTierVM$i" `
        -Location "CentralIndia" `
        -VirtualNetworkName "fc3TierVnet" `
        -SubnetName "DataTier" `
        -AvailabilitySetName "fcDataTierAvailabilitySet" `        
        -Credential $cred
        -AsJobs
   }

   write-host "Data Tier VM configuration completed" -ForegroundColor Green
}
catch
{
   write-host "An exception occured:" -ForegroundColor Red
   write-host "Exception Type: $($_.Exception.GetType().FullName)" -ForegroundColor Red
   write-host "Exception Message: $($_.Exception.Message)" -ForegroundColor Red
}
finally
{

}

