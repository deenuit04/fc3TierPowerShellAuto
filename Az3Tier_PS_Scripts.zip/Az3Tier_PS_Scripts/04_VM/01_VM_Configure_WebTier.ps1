$ErrorActionPreference = "Stop"

try
{
   $vnet = Get-AzVirtualNetwork -Name fc3TierVnet -ResourceGroupName fc3TierVnetResourceGroup

   $backendSubnet = Get-AzVirtualNetworkSubnetConfig `
  -Name WebTier `
  -VirtualNetwork $vnet

   $webAsg = Get-AzApplicationSecurityGroup `
  -ResourceGroupName "fc3TierVnetResourceGroup" `
  -Name "fc3TierASGWebServers" `

   $nsg = Get-AzNetworkSecurityGroup `
  -ResourceGroupName "fc3TierVnetResourceGroup" `
  -Name "fcWebTierNsg" `

   $lb = Get-AzLoadBalancer `
  -ResourceGroupName fc3TierVnetResourceGroup `
  -Name "fc3TierWebLoadBalancer"

   write-host "Configure Web Tier VM Availability Set" -ForegroundColor Yellow
   
   New-AzAvailabilitySet `
   -Location "SouthIndia" `
   -Name "fcWebTierAvailabilitySet" `
   -ResourceGroupName "fc3TierVnetResourceGroup" `
   -Sku aligned `
   -PlatformFaultDomainCount 2 `
   -PlatformUpdateDomainCount 2

   write-host "Configure Web Tier VM Availability Set completed" -ForegroundColor Green
   
   write-host "Configure Web Tier VMs" -ForegroundColor Yellow

write-host "Creating NIC1" -ForegroundColor Yellow
   $nic1 = New-AzNetworkInterface `
-ResourceGroupName "fc3TierVnetResourceGroup" `
-Location "SouthIndia" `
-Subnet $backendSubnet `
-Name "fcWebTierVM1" `
-ApplicationSecurityGroup $webAsg `
-NetworkSecurityGroup $nsg `
-LoadBalancerBackendAddressPool $lb.BackendAddressPools[0] `
-LoadBalancerInboundNatRule $lb.InboundNatRules[0]

write-host "Creating NIC2" -ForegroundColor Yellow
$nic2 = New-AzNetworkInterface `
-ResourceGroupName "fc3TierVnetResourceGroup" `
-Location "SouthIndia" `
-Subnet $backendSubnet `
-Name "fcWebTierVM2" `
-ApplicationSecurityGroup $webAsg `
-NetworkSecurityGroup $nsg `
-LoadBalancerBackendAddressPool $lb.BackendAddressPools[0] `
-LoadBalancerInboundNatRule $lb.InboundNatRules[1]

write-host "Creating VM1" -ForegroundColor Yellow
New-AzVm `
        -ResourceGroupName "fc3TierVnetResourceGroup" `
        -Name "fcWebTierVM1" `
        -Location "SouthIndia" `
        -VirtualNetworkName "fc3TierVnet" `
        -SubnetName "WebTier" `
        -AvailabilitySetName "fcWebTierAvailabilitySet" `        
-AsJob

write-host "Creating VM2" -ForegroundColor Yellow
New-AzVm `
        -ResourceGroupName "fc3TierVnetResourceGroup" `
        -Name "fcWebTierVM2" `
        -Location "SouthIndia" `
        -VirtualNetworkName "fc3TierVnet" `
        -SubnetName "WebTier" `
        -AvailabilitySetName "fcWebTierAvailabilitySet" `
-AsJob

   write-host "Web Tier VM configuration has been scheduled" -ForegroundColor Green
}
catch
{
   write-host "An exception occured:" -ForegroundColor Red
   write-host "Exception Type: $($_.Exception.GetType().FullName)" -ForegroundColor Red
   write-host "Exception Message: $($_.Exception.Message)" -ForegroundColor Red
}
finally
{

}

