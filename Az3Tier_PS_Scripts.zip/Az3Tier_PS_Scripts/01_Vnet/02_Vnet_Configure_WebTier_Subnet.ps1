$ErrorActionPreference = "Stop"

try
{
   write-host "Configure Web Tier subnet" -ForegroundColor Yellow

   $virtualNetwork = Get-AzVirtualNetwork -Name fc3TierVnet -ResourceGroupName fc3TierVnetResourceGroup

   $subnetConfig = Add-AzVirtualNetworkSubnetConfig `
  -Name WebTier `
  -AddressPrefix 192.168.1.0/24 `
  -VirtualNetwork $virtualNetwork

   $virtualNetwork | Set-AzVirtualNetwork

   write-host "Web Tier subnet configuration completed" -ForegroundColor Green
}
catch
{
   write-host "An exception occured:" -ForegroundColor Red
   write-host "Exception Type: $($_.Exception.GetType().FullName)" -ForegroundColor Red
   write-host "Exception Message: $($_.Exception.Message)" -ForegroundColor Red
}
finally
{

}

