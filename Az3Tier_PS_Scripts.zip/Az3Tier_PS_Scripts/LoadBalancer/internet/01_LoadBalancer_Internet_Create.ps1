$ErrorActionPreference = "Stop"

try
{
   write-host "Create the public IP address" -ForegroundColor Yellow

   $publicIP = New-AzPublicIpAddress `
  -ResourceGroupName "fc3TierVnetResourceGroup" `
  -Location "CentralIndia" `
  -AllocationMethod "Static" `
  -Name "fc3TierPublicIP"

  write-host "Create the frontend IP pool" -ForegroundColor Yellow

  $frontendIP = New-AzLoadBalancerFrontendIpConfig `
  -Name "fc3TierFrontEndPool" `
  -PublicIpAddress $publicIP

  write-host "Create the backend address pool" -ForegroundColor Yellow

  $backendPool = New-AzLoadBalancerBackendAddressPoolConfig `
  -Name "fc3TierBackEndPool"

  write-host "Create the load balancer" -ForegroundColor Yellow

  $lb = New-AzLoadBalancer `
  -ResourceGroupName "fc3TierVnetResourceGroup" `
  -Name "fc3TierInternetLoadBalancer" `
  -Location "CentralIndia" `
  -FrontendIpConfiguration $frontendIP `
  -BackendAddressPool $backendPool

  write-host "Load balancer creation completed" -ForegroundColor Green
}
catch
{
   write-host "An exception occured:" -ForegroundColor Red
   write-host "Exception Type: $($_.Exception.GetType().FullName)" -ForegroundColor Red
   write-host "Exception Message: $($_.Exception.Message)" -ForegroundColor Red
}
finally
{

}

