$ErrorActionPreference = "Stop"

try
{
   write-host "Configure fc3TierInternetLoadBalancer with health probe of VMs" -ForegroundColor Yellow

   $lb = Get-AzLoadBalancer -Name "fc3TierInternetLoadBalancer" -ResourceGroupName "fc3TierVnetResourceGroup"

   Add-AzLoadBalancerProbeConfig `
  -Name "fc3TierFrontEndHealthProbe" `
  -LoadBalancer $lb `
  -Protocol tcp `
  -Port 80 `
  -IntervalInSeconds 15 `
  -ProbeCount 2

   Set-AzLoadBalancer -LoadBalancer $lb
  
   $probe = Get-AzLoadBalancerProbeConfig -LoadBalancer $lb -Name "fc3TierFrontEndHealthProbe"

   Add-AzLoadBalancerRuleConfig `
  -Name "fc3TierInternetLoadBalancerRule" `
  -LoadBalancer $lb `
  -FrontendIpConfiguration $lb.FrontendIpConfigurations[0] `
  -BackendAddressPool $lb.BackendAddressPools[0] `
  -Protocol Tcp `
  -FrontendPort 80 `
  -BackendPort 80 `
  -Probe $probe

   Set-AzLoadBalancer -LoadBalancer $lb

   write-host "Load balancer configuration completed" -ForegroundColor Green
}
catch
{
   write-host "An exception occured:" -ForegroundColor Red
   write-host "Exception Type: $($_.Exception.GetType().FullName)" -ForegroundColor Red
   write-host "Exception Message: $($_.Exception.Message)" -ForegroundColor Red
}
finally
{

}

