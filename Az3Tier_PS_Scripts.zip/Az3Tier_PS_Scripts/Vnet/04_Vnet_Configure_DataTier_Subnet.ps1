$ErrorActionPreference = "Stop"

try
{
   write-host "Configure Data Tier subnet" -ForegroundColor Yellow

   $virtualNetwork = Get-AzVirtualNetwork -Name fc3TierVnet -ResourceGroupName fc3TierVnetResourceGroup

   $subnetConfig = Add-AzVirtualNetworkSubnetConfig `
  -Name DataTier `
  -AddressPrefix 192.168.3.0/24 `
  -VirtualNetwork $virtualNetwork

   $virtualNetwork | Set-AzVirtualNetwork

   write-host "Data Tier subnet configuration completed" -ForegroundColor Green
}
catch
{
   write-host "An exception occured:" -ForegroundColor Red
   write-host "Exception Type: $($_.Exception.GetType().FullName)" -ForegroundColor Red
   write-host "Exception Message: $($_.Exception.Message)" -ForegroundColor Red
}
finally
{

}

