$ErrorActionPreference = "Stop"

try
{
   write-host "Create the Virtual Network" -ForegroundColor Yellow
   
   $virtualNetwork = New-AzVirtualNetwork `
   -ResourceGroupName fc3TierVnetResourceGroup `
   -Location "CentralIndia" `
   -Name fc3TierVnet `
   -AddressPrefix 192.168.0.0/16
   
  write-host "Virtual Network creation completed" -ForegroundColor Green
}
catch
{
   write-host "An exception occured:" -ForegroundColor Red
   write-host "Exception Type: $($_.Exception.GetType().FullName)" -ForegroundColor Red
   write-host "Exception Message: $($_.Exception.Message)" -ForegroundColor Red
}
finally
{

}

